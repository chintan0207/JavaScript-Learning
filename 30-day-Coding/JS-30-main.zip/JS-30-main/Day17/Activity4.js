// Activity 4: Binary Tree

// Task 7: Implement a TreeNode class to represent a node in a binary tree with properties value, left, and right.
// Task 8: Implement a BinaryTree class with methods for inserting values and performing in-order traversal to display nodes.