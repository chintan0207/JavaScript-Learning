// Activity 2: Stack

// Task 3: Implement a Stack class with methods push (add element), pop (remove element), and peek (view the top element).
// Task 4: Use the Stack class to reverse a string by pushing all characters onto the stack and then popping them off.