# CHAT App

Instruction for installation:

```bash
npm install
```
run serever:

```bash
node index.js
```
Open html/index.html with liveserver