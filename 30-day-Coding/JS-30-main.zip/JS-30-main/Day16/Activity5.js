// Activity 5: Tree Traversal (Optional)

// Task 9: Write a recursive function to perform an in-order traversal of a binary tree. Log the nodes as they are visited.
// Task 10: Write a recursive function to calculate the depth of a binary tree. Log the result for a few test cases.

// TODO: KEPT FOR LATER WORK