import userDetails from './Activity3a.mjs'

const {address, user, music} = userDetails;

console.log(address);
console.log(user);
music.play()