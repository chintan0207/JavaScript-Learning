import { person, sum } from "./Activity1a.mjs";

console.log(sum(10,50));
console.log(person.name);
person.sleep();