import average , { sum,sub,product } from "./Activity2a.mjs";

console.log(sum(10,50));
console.log(sub(90,50));
console.log(product(9,5));
console.log(average(7,5,9,6,3,8));